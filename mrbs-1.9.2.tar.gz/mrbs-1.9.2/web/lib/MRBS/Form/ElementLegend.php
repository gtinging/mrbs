<?php

namespace MRBS\Form;

class ElementLegend extends Element
{

  public function __construct()
  {
    parent::__construct('legend');
  }
 
}