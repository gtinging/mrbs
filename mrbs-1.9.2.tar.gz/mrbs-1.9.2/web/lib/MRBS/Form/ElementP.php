<?php

namespace MRBS\Form;

class ElementP extends Element
{
  
  public function __construct()
  {
    parent::__construct('p');
  }
 
}