<?php

namespace MRBS\Form;

class ElementSpan extends Element
{
  
  public function __construct()
  {
    parent::__construct('span');
  }
 
}