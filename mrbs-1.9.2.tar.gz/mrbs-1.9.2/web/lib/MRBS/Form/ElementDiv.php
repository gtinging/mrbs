<?php

namespace MRBS\Form;

class ElementDiv extends Element
{

  public function __construct()
  {
    parent::__construct('div');
  }
 
}