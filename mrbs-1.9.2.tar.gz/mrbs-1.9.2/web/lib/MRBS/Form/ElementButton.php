<?php

namespace MRBS\Form;

class ElementButton extends Element
{
  
  public function __construct()
  {
    parent::__construct('button');
  }
 
}