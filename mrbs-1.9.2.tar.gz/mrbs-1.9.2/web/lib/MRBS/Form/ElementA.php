<?php

namespace MRBS\Form;

class ElementA extends Element
{
  
  public function __construct()
  {
    parent::__construct('a');
  }
 
}